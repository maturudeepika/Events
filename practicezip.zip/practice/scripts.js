document.addEventListener("DOMContentLoaded", function() {
    new Typed('.hero-title', {
        strings: ["Guest Lectures", "Internships", "Coding Competitions", "Presentations"],
        typeSpeed: 60,
        backSpeed: 30,
        loop: true
    });
});

document.addEventListener('DOMContentLoaded', function() {
    const calendarToggle = document.getElementById('calendar-toggle');
    const calendar = document.getElementById('calendar');
    
    calendarToggle.addEventListener('click', function() {
        // Toggle the display of the calendar
        if (calendar.style.display === 'none' || calendar.style.display === '') {
            calendar.style.display = 'flex';
        } else {
            calendar.style.display = 'none';
        }
    });
  });

  
  
